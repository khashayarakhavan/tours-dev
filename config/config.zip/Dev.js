// development keys

module.exports = {
    googleClientID: '413253657609-97cp59tetj2rcof9fi896jr9pkb5eb8e.apps.googleusercontent.com',
    googleClientSecret: 'vHtGhiEB8HUJH429BIOm9LqA',
    mongoURI: 'mongodb+srv://aftoflbig5:shajabaja@cluster0-fu5yu.mongodb.net/OAuth?retryWrites=true&w=majority',
    cookieKey: 'redacted',
    stripePublishableKey: 'pk_test_KNUVmRm968NGSXoP95l8IKrw00MIP7aUjm',
    stripeSecretKey: 'sk_test_p7RyyluCAlU65aN1R0Y5NYj400BOmYZ9it',
    redirectDomain: 'http://localhost:3000',
    sendMailGunKey: 'key-bebfe08cf9c504510a446dcdbf333a01',
    sendMailGunDomain: 'sandbox5d27f177cbf9492890f0d8d444cb9a15.mailgun.org'
};
